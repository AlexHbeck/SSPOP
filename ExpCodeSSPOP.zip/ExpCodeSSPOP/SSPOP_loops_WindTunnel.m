%% Sparse Sensor Placement Optimization for Prediction (SSPOP)
% by Alex C. Hollenbeck. See "Experimental Validation of Sparse Sensor 
% Placement Optimization for Flight-By-Feel of a Delta Wing,"
% J. Structural and Multidisciplinary Optimization,submitted July 2024
% This code is derived from the SSPOC and SSPOR algorithms developed by
% Brunton, Manohar, Kutz, et. al. See especially DOI. 10.1137/15M1036713
% and  https://doi.org/10.48550/arXiv.1701.07569clear all; close all;
% definitions and data

warning('off','all');
warning;

% Import CFD Flow Data
load FlowDataFinal.mat

Y = YTR;
Ytest = YTE; % Test Angles
X = XTR'; % Training Data

m = length(Y); % number AoA categories in dataset
G = [1:m]'; 
nx = 1; % number of repeat measurements per category (per AoA)
ny = length(X); % number of nodes in each measurement

n = nx * ny;    % total variables (candidate sensor locations)
m = length(G);         % number of measurements
classes = unique(G);    % vector of classes
c = numel(classes);     % number of classes 

tic
% for Q = 1:4
Q = 6; % number of sensors

rmse=zeros(4,m);
Lambda = [0 1 10 100];

for L = 1:1:4
    lambda = Lambda(L);
for r = Q:1:m

    % r and lambda may be chosen by experience or by exploring the whole 
%   space by loops. r varies from 1 to m while lambda may be zero,
%   1, 10, or 100. Sometimes r corresponds to the "elbow" or inflection 
%   point in the singular value chart plotted next.

%% Pre-process with Singular Value Decomposition (a type of PCA)

[U, Sigma, V] = svd(X, 'econ'); % U-->Psi, sigma-->E, V-->V*  (eq 2.4)
dS = diag(Sigma)/sum(Sigma(:)); % the singular values of X


%% Linear Discriminant Analysis (LDA)

d = size(X, 1);
Psi = U(:, 1:r); % truncated basis PSI to first r modes
a = Psi'*X; % a is the r-dimensional feature space of X

N = zeros(1, c); % total measurements in each class
for i = 1:c
    N(i) = sum(G==classes(i)); 
    centroid(:,i) = mean(X(:, G==classes(i)), 2);
end

Sw = zeros(d, d); % the within class variance (will be zero for singular classes)
for i = 1:c
    res = X(:,G==classes(i)) - centroid(:,i)*ones(1,N(i));
    Sw = Sw + (res)*(res)';
end

Sb = zeros(d, d); % the between class variance
for i = 1:c
    Sb = Sb + N(i) * (centroid(:,i)-mean(X,2))*(centroid(:,i)-mean(X,2))';
end

% solve for the eigenvalues of inv(Sw)*Sb,
% keep eigenvectors with c largest magnitude eigenvalues
[w, D] = eigs(pinv(Sw) * Sb, c);

% normalize w vectors (my data is already normalized to freestream V)
for i = 1:size(w,2)
    w(:,i) = w(:,i) / sqrt(w(:,i)'*w(:,i));
end

w = w([1:r],:); % take first r rows of weights matrix
Xcls = w' * a;

%% SSPOP - generate the sparse solution s
epsilon = 1e-10; % error tolerance for reconstruction
unit = ones(c,1);
cvx_begin quiet
    variable s( n, c )
    minimize( norm(s(:),1) + lambda*norm(s*unit,1) ); 
    subject to
        norm(Psi'*s - w, 'fro') <= epsilon 
cvx_end

%% Step 2 - using sparse solution s, choose q sensor locations corresponding
% to the q rows of s containing at least one nonzero entry. In practice,
% a useful threshold is to find elements of s where |sij| >= ||s||F/(2*c*r)
S = abs(s(:,:)); 
for k = 1:ny % This creates a vector of the total size of each sensor in s
    S(k,:) = sort(abs(s(k,:)),'descend');  
    k = k+1;
end
Top = sort(S,'descend'); % this puts S in descending order. 
R = Top(Q);

sensors = S >= R;

[row,col,q] = find(sensors);
sensors = unique(row); % this is the x-locations (DP) of the sensors
q = numel(sensors); 

% construct the measurement matrix Phi (ones correspond to sensors)
Phi = zeros(q, n);
for qi = 1:q,
    Phi(qi, sensors(qi)) = 1; 
end;

%% Regression and testing of DP
DP = sensors(:)'; 
out = zeros(size(X)); 
out(DP,:) = X(DP,:); 
out = out';

Bdp = regress(Y,out); % this regression gives a rank deficient warning
              % but this is ok because the columns are mostly zeros
pred = XTE*Bdp;
RMSE(L,r) = sqrt(mean((pred-Ytest).^2))

r = r+1;
end
L=L+1;
r=1;
end

min(RMSE(:,Q:end))
bestRMSE(Q) = min(ans)

toc


