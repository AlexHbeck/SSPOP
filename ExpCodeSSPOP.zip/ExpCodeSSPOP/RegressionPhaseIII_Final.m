clear all

% Import Data
load FlowDataFinal.mat
Y       = YTR;
Ytest   = YTE; % Test Angles
X       = XTR; % Training Data
Xtest   = XTE;

warning('off','all');
warning;

n = length(X) % number of node locations
s = 3 % number of sensors
dp = combinator(n,s,'c'); % all combinations without repetition
num_dp = length(dp)

tic

for i = 1:num_dp
    DP = dp(i,:);
    out = zeros(size(X));
    out(:,DP) = X(:,DP);
    Bdp = regress(Y,out); % this regression gives a rank deficient warning
              % But this is ok becuase the columns are mostly zeros
    pred = Xtest*Bdp;
    RMSE(i) = sqrt(mean((pred-Ytest).^2));
    i = i+1;
end

[max_num, max_idx]=max(RMSE(:)); % find maximum RMSE and corresponding DP(s)
[X,Y]=ind2sub(size(RMSE),find(RMSE==max_num));
WorstDP = dp(Y,:); % report the worst design point
RMSE_max = RMSE(Y);

[min_num, min_idx]=min(RMSE(:)); % find min accuracy and corresponding DP
[Q,Z]=ind2sub(size(RMSE),find(RMSE==min_num));
Best_DP = dp(Z,:) 
RMSE_min = RMSE(Z)

results = [dp RMSE'];

RMSE_sorted = sort(RMSE,'ascend');

toc


