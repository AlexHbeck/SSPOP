close all
clear all
load 'NodesMetric'
%load 'Nodes3'
sz  =   7; %size of node dots
N   =   3; % number of nodes to randomly select
sz2 =   65; % size of selected node dots

A = randn(size(NodesFinal(:,1)));
B = sort(A,"ascend");

fill(z,x,'g')
hold on
scatter(NodesFinal(:,1),NodesFinal(:,2),sz,'black','filled','o')
hold on

% dp =   [15	20	129];   % SSPOP_1
% dp =   [20	95	131];   % SSPOP_2
 dp =   [32	57	165];   % Best Possible
% dp  =   [78 142 201];   % Expert Opinion

n1 = num2str(dp(1));
n2 = num2str(dp(2));
n3 = num2str(dp(3));

for n = 1:N
scatter(NodesFinal(dp(n),1),NodesFinal(dp(n),2),sz2,'black','filled','o')
hold on
nodes(n,:) = NodesFinal(dp(n),:);
n = n+1;
end

title('Best Possible') % change as needed
xlabel('Z, mm')
ylabel('X, mm')

text(155,215,'Design Point')
text(155,188,'n1') % will need to add or subtract lines if changing n
text(155,175,'n2')
text(155,162,'n3')
text(180,200,"Z")
text(195,200,"X")
text(175,175,num2str(nodes))


