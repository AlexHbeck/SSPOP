clear all
% Import Data 
load FlowDataFinal.mat
Y       = YTR;
Ytest   = YTE; % Test Angles
X       = XTR; % Training Data
Xtest   = XTE;

warning('off','all');
warning;

n = length(X) % number of node locations
s = 3 % number of sensors
%dp = combinator(n,s,'c'); % all combinations without repetition
%num_dp = length(dp)

dp = [  66	126	211     % R1
        11	47	89      % R2
        115	223	240     % R3
        15	20	129     % SSPOP
        20	95	131     % SSPOP 2
        32	57	165     %BP
        78  142 201     %ExpOp
        127 108 130 ]     %AtticusBest  
       
dp1 = [20];
dp2 = [57 240];
dp3 = [32 129 240];
dp4 = [32 57 129 240];
dp5 = [15 20 32 57 165];
dp6 = [15 20 32 57 129 165];

for i = 1:length(dp)
    DP = dp(i,:);
    out = zeros(size(X));
    out(:,DP) = X(:,DP);
    Bdp = regress(Y,out); % this regression gives a rank deficient warning
              % But this is ok becuase the columns are mostly zeros
    pred = Xtest*Bdp;
    RMSE(i) = sqrt(mean((pred-Ytest).^2));
    i = i+1;
end

results = [dp RMSE']

    DP = dp1;
    out = zeros(size(X));
    out(:,DP) = X(:,DP);
    Bdp = regress(Y,out); % this regression gives a rank deficient warning
              % But this is ok becuase the columns are mostly zeros
    pred = Xtest*Bdp;
    RMSE1 = sqrt(mean((pred-Ytest).^2));

    DP = dp2;
    out = zeros(size(X));
    out(:,DP) = X(:,DP);
    Bdp = regress(Y,out); % this regression gives a rank deficient warning
              % But this is ok becuase the columns are mostly zeros
    pred = Xtest*Bdp;
    RMSE2 = sqrt(mean((pred-Ytest).^2));

    DP = dp3;
    out = zeros(size(X));
    out(:,DP) = X(:,DP);
    Bdp = regress(Y,out); % this regression gives a rank deficient warning
              % But this is ok becuase the columns are mostly zeros
    pred = Xtest*Bdp;
    RMSE3 = sqrt(mean((pred-Ytest).^2));

    DP = dp4;
    out = zeros(size(X));
    out(:,DP) = X(:,DP);
    Bdp = regress(Y,out); % this regression gives a rank deficient warning
              % But this is ok becuase the columns are mostly zeros
    pred = Xtest*Bdp;
    RMSE4 = sqrt(mean((pred-Ytest).^2));

    DP = dp5;
    out = zeros(size(X));
    out(:,DP) = X(:,DP);
    Bdp = regress(Y,out); % this regression gives a rank deficient warning
              % But this is ok becuase the columns are mostly zeros
    pred = Xtest*Bdp;
    RMSE5 = sqrt(mean((pred-Ytest).^2));

    DP = dp6;
    out = zeros(size(X));
    out(:,DP) = X(:,DP);
    Bdp = regress(Y,out); % this regression gives a rank deficient warning
              % But this is ok becuase the columns are mostly zeros
    pred = Xtest*Bdp;
    RMSE6 = sqrt(mean((pred-Ytest).^2));
    
    res1 = [dp1 RMSE1']
    res2 = [dp2 RMSE2']
    res3 = [dp3 RMSE3']
    res4 = [dp4 RMSE4']
    res5 = [dp5 RMSE5']
    res6 = [dp6 RMSE6']
      


%RMSE_sorted = sort(RMSE,'ascend')




