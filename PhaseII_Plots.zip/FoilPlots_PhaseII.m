clear all; close all; 

load PhaseIIfoil.mat; % airfoil coordinates (update for Phase II) load PhaseIIfoil.mat
load ConstNodes.mat; % constrained

x = PhaseIIfoil(:,1);
y = PhaseIIfoil(:,2);

DP = [  1   74  0    0   0   0   0   0   0   0   0   0   0   0  0   % Full 1
        74  77  0    0   0   0   0   0   0   0   0   0   0   0  0   % Con0st 01
        72  95  67  94   0   0   0   0   0   0   0   0 	 0   0  0   % Full 2
        72  95	64	94 	 0   0   0   0   0   0   0   0   0   0  0   % Const 2
		50  66  95  52  64  94  50  64  94   0   0   0   0   0  0   % Full 3
		50  66  94  64  66  94  50  66  96   0   0   0   0   0  0   % Const 3
        50  68  98  100 18  65  66  80  48  74  95  122  0   0  0   % Full 4
        50  68  98  100 64  72  94  105 52  71  98  102  0   0  0   % Const 4
        65  73  94  105 135 67  73  83  133 138  6  57  68  96  99  % Full 5
        65  73  94  105 135 21  62  69  93  116 58  75  96  100 132 % Const 5
       ];

%DPc=DP;
s = 3; % size of node dots
S = 12; % size of sensor dots
L = 4; %LINE WIDTH

l = 0.1; % title left spacing
r = 0.3; % title vertical spacing

%tit = ["Reference Model" "Turbulence set to Zero" "Turbulence = 1.1 top, 0.9 bottom"]
t1 = tiledlayout(5,2, 'TileSpacing','compact','Padding','compact')
% tiledlayout('flow')

nexttile % Full 1
plot(x,y,'b','linewidth',L) % airfoil shape
hold on
plot(x,y,'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s) % full airfoil nodes
plot(x(DP(1,1)),y(DP(1,1)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % BP
plot(x(DP(1,2)),y(DP(1,2)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
title("A. Full, 1 sensor", 'Units',  'normalized','HorizontAlalignment', 'left', 'Position', [l,r]);

nexttile % Constrained 1
plot(x,y,'b','linewidth',L) % airfoil shape
hold on
plot(ConstNodes(:,1),ConstNodes(:,2),'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s) % Constrained nodes
plot(x(DP(2,1)),y(DP(2,1)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % Best Possible
plot(x(DP(2,2)),y(DP(2,2)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
title("B. Constrained, 1 sensor", 'Units', 'normalized', 'HorizontAlalignment', 'left', 'Position', [l,r]);

nexttile % Full 2
plot(x,y,'b','linewidth',L) % airfoil shape
hold on
plot(x,y,'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s) % full airfoil nodes
plot(x(DP(3,1:2)),y(DP(3,1:2)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % BP
plot(x(DP(3,3:4)),y(DP(3,3:4)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
title("C. Full, 2 sensors", 'Units',  'normalized','HorizontAlalignment', 'left', 'Position', [l,r]);

nexttile % Constrained 2
plot(x,y,'b','linewidth',L) % airfoil shape
hold on
plot(ConstNodes(:,1),ConstNodes(:,2),'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s) % Constrained nodes
plot(x(DP(4,1:2)),y(DP(4,1:2)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % Best Possible
plot(x(DP(4,3:4)),y(DP(4,3:4)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
title("D. Constrained, 2 sensors", 'Units', 'normalized', 'HorizontAlalignment', 'left', 'Position', [l,r]);

nexttile % Full 3
plot(x,y,'b','linewidth',L) % airfoil shape
hold on
plot(x,y,'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s) % full airfoil nodes
plot(x(DP(5,1:3)),y(DP(5,1:3)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % BP
plot(x(DP(5,4:6)),y(DP(5,4:6)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
plot(x(DP(5,7:9)),y(DP(5,7:9)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8) % SSPOP+GS
title("E. Full, 3 sensors", 'Units',  'normalized','HorizontAlalignment', 'left', 'Position', [l,r]);

nexttile % Constrained 3
plot(x,y,'b','linewidth',L) % airfoil shape
hold on
plot(ConstNodes(:,1),ConstNodes(:,2),'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s) % Constrained nodes
plot(x(DP(6,1:3)),y(DP(6,1:3)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % Best Possible
plot(x(DP(6,4:6)),y(DP(6,4:6)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
plot(x(DP(6,7:9)),y(DP(6,7:9)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8) % SSPOP+GS
title("F. Constrained, 3 sensors", 'Units', 'normalized', 'HorizontAlalignment', 'left', 'Position', [l,r]);

nexttile % Full 4
plot(x,y,'b','linewidth',L) % airfoil shape
hold on
plot(x,y,'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s) % full airfoil nodes
plot(x(DP(7,1:4)),y(DP(7,1:4)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % BP
plot(x(DP(7,5:8)),y(DP(7,5:8)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
plot(x(DP(7,9:12)),y(DP(7,9:12)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8) % SSPOP+GS

title("G. Full, 4 sensors", 'Units',  'normalized','HorizontAlalignment', 'left', 'Position', [l,r]);

nexttile % Constrained 4
plot(x,y,'b','linewidth',L) % airfoil shape
hold on
plot(ConstNodes(:,1),ConstNodes(:,2),'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s) % Constrained nodes
plot(x(DP(8,1:4)),y(DP(8,1:4)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % BP
plot(x(DP(8,5:8)),y(DP(8,5:8)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
plot(x(DP(8,9:12)),y(DP(8,9:12)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8) % SSPOP+GS
title("H. Constrained, 4 sensors", 'Units', 'normalized', 'HorizontAlalignment', 'left', 'Position', [l,r]);

nexttile % Full 5
plot(x,y,'b','linewidth',L) % airfoil shape
hold on
plot(x,y,'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s) % full airfoil nodes
plot(x(DP(9,1:5)),y(DP(9,1:5)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % BP
plot(x(DP(9,6:10)),y(DP(9,6:10)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
plot(x(DP(9,11:15)),y(DP(9,11:15)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8) % SSPOP+GS
title("I. Full, 5 sensors", 'Units',  'normalized','HorizontAlalignment', 'left', 'Position', [l,r]);

nexttile % Constrained 5
plot(x,y,'b','linewidth',L) % airfoil shape
hold on
plot(ConstNodes(:,1),ConstNodes(:,2),'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s) % Constrained nodes
plot(x(DP(10,1:5)),y(DP(10,1:5)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % BP
plot(x(DP(10,6:10)),y(DP(10,6:10)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
plot(x(DP(10,11:15)),y(DP(10,11:15)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8) % SSPOP+GS
title("J. Constrained, 5 sensors", 'Units', 'normalized', 'HorizontAlalignment', 'left', 'Position', [l,r]);

leg = legend('Airfoil Shape', 'Nodes', 'Best Possible', 'SSPOP', 'SSPOP + Search')
leg.Layout.Tile = 'north','horizontal';
%title(t1, 'Phase II Design Points')