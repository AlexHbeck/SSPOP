%% SSPOP in one file
%% Sparse Sensor Placement Optimization for Prediction (SSPOP)
% by Alex C. Hollenbeck. See "Artificial Hair Sensor Placement Optimization
% on Airfoils for Angle of Attack Prediction," 2023 AIAA SciTech Paper.
% This code is derived from the SSPOC and SSPOR algorithms developed by
% Brunton, Manohar, Kutz, et. al. See especially DOI. 10.1137/15M1036713
% and  https://doi.org/10.48550/arXiv.1701.07569
clear all; close all;
% definitions and data

warning('off','all');
warning;

%load X75_Full0.mat % load velocity matrix for Regression
%load X25_Full0.mat % load velocity matrix for Testing

%load X75_Full.mat % load velocity matrix for Regression
%load X25_Full.mat % load velocity matrix for Testing

% Full NACA 0012 no adjustment 10 mps same conditions
load X75_0012.mat
load X25_0012.mat
load Y75_0012.mat
load Y25_0012.mat

% Original Values LE to TE, LE to TE
%load X75_FullOriginal.mat % load velocity matrix for Regression
%load X25_FullOriginal.mat % load velocity matrix for Testing

% CONSTRAINED WRAPAROUND with Turb = 0
%load X75_Const0.mat % load velocity matrix for Regression
%load X25_Const0.mat % load velocity matrix for Testing

% CONSTRAINED Turb = 1.1 for top and 0.9 for bottom
%load X75_ConstALT.mat % load velocity matrix for Regression
%load X25_ConstALT.mat % load velocity matrix for Testing

% FULL Turb = 1.1 for top and 0.9 for bottom
%load X75_FullALTurb.mat
%load X25_FullALTurb.mat

%load X75_FullLamOnly.mat % load velocity matrix for Regression
%load X25_FullLamOnly.mat % load velocity matrix for Testing

% Bottom Surface
%load X75_Bottom4415.mat % load velocity matrix for Regression
%load X25_Bottom4415.mat % load velocity matrix for Testing
%load Y75pos.mat;
%load Y25pos.mat;

% Top Surface
%load X75_Top4415.mat % load velocity matrix for Regression
%load X25_Top4415.mat % load velocity matrix for Testing
%load Y25neg.mat
%load Y75neg.mat

% Xtest = X25_Full0;
% Xtest = X25_Full;
% Xtest = X25_FullOriginal;
% Xtest = X25_Const0;
% Xtest = X25_ConstALT;
% Xtest = X25_FullALTurb;
Xtest = X25_0012;
% Xtest = X25_FullLamOnly;
% Xtest = X25_Bottom4415;
% Xtest = X25_Top4415;

%load Y75all.mat % load AoA matrix for regression
%load Y25all.mat % load AoA matrix for testing

% Y = Y75all;
Y = Y75_0012;
% Ytest = Y25all;
Ytest = Y25_0012;
%Y = Y75neg; %Top
%Y = Y75pos; %Bottom
%Ytest = Y25neg; %Top
%Ytest = Y25pos; %Bottom

% X     data matrix, 200 (nx by ny) nodes by m measurements
% X = X75_Full0';
% X = X75_Full';
% X = X75_Const0';
% X = X75_ConstALT';
% X = X75_FullALTurb';
X = X75_0012';
% X = X75_FullOriginal';
% X = X75_FullLamOnly';
% X = X75_Bottom4415';
% X = X75_Top4415';

m = length(Y); % there are 53 AoA categories in this data set
G = [1:m]';
nx = 1; % Repeat measurements within classes
ny = length(X); % number of nodes
n = nx * ny;    % total variables
m = length(G);         % number of measurements
classes = unique(G);    % vector of classes
c = numel(classes);     % number of classes 

%% Inputs

Q = 1; % number of sensors
% r and lambda may be chosen by experience or by exploring the whole 
%   space by loops. r varies from 1 to m while lambda may be zero,
%   1, 10, or 100. Sometimes r corresponds to the "elbow" in the 
%   singular value chart plotted next.
r = 7; % truncate PSI to the first r modes or features
lambda = 1; % The choice of lambda determines the sparsity in s.

%% Pre-process with Singular Value Decomposition (a type of PCA)

[U, Sigma, V] = svd(X, 'econ'); % U-->Psi, sigma-->E, V-->V*  (eq 2.4)
dS = diag(Sigma)/sum(Sigma(:)); % the singular values of X
figure;
semilogy(dS(1:m), 'k');
xlabel('i');
ylabel('\sigma_i');
grid on;
title('Singular Value Spectrum');
set(gcf, 'Position', [100 100 300 300]);

%% Linear Discriminant Analysis (LDA)

d = size(X, 1);
Psi = U(:, 1:r); % truncated basis PSI to first r modes
a = Psi'*X; % a is the r-dimensional feature space of X

N = zeros(1, c);   % mean measurement at each x in each class. 
  % Centroid = X as we have no repeat measurements.
for i = 1:c
    N(i) = sum(G==classes(i)); % all ones as only one measurement per class
    centroid(:,i) = mean(X(:, G==classes(i)), 2);
end

Sw = zeros(d, d); % the within class variance (will be zero for singular classes)
    % simply each measurment in x minus the average measurement in x
for i = 1:c
    res = X(:,G==classes(i)) - centroid(:,i)*ones(1,N(i));
    Sw = Sw + (res)*(res)';
end

Sb = zeros(d, d); % the between class variance
for i = 1:c
    Sb = Sb + N(i) * (centroid(:,i)-mean(X,2))*(centroid(:,i)-mean(X,2))';
end

% solve for the eigenvalues of inv(Sw)*Sb,
% keep eigenvectors with c largest magnitude eigenvalues
[w, D] = eigs(pinv(Sw) * Sb, c);

% normalize w vectors (my data is already normalized to freestream V)
for i = 1:size(w,2)
    w(:,i) = w(:,i) / sqrt(w(:,i)'*w(:,i));
end

w = w([1:r],:); % take first r rows of weights matrix
Xcls = w' * a;

%% Finding the Sparse Solution
% Step 1 - Find s
% solve Psi'*s = w, using the l1 norm to promote sparsity

epsilon = 1e-15; % error tolerance for reconstruction
%[n, r] = size(Psi); %#ok<ASGLU>
%c = size(w, 2); % number of classes
% solve Psi'*s = w
% using the l1 norm to promote sparsity
unit = ones(c,1);
cvx_begin quiet
    variable s( n, c )
    minimize( norm(s(:),1) + lambda*norm(s*unit,1) ); 
    subject to
        norm(Psi'*s-w, 'fro') <= epsilon 
cvx_end

%% Step 2 - using sparse solution s, choose Q sensor locations corresponding
% to the Q rows of s containing at least one nonzero entry. In practice,
% a useful threshold is to find elements of s where |sij| >= ||s||F/(2*c*r)
S = abs(s(:,:)); 
for k = 1:ny % This creates a vector of the total size of each node in s
    S(k,:) = sort(abs(s(k,:)),'descend');  
    k = k+1;
end
Top = sort(S,'descend'); % this puts S in descending order. 
R = Top(Q);

sensors = S >= R;

[row,col,q] = find(sensors);
sensors = unique(row); % this is the x-locations (DP) of the sensors
q = numel(sensors); % should equal Q

% construct the measurement matrix Phi (ones correspond to sensors)
Phi = zeros(q, n);
for qi = 1:q,
    Phi(qi, sensors(qi)) = 1; 
end;

%% Regression and testing of DP
DP = sensors(:)'
out = zeros(size(X)); 
out(DP,:) = X(DP,:); 
out = out';

Bdp = regress(Y,out); % this regression gives a rank deficient warning
              % but this is ok becuase the columns are mostly zeros
              % therefore warnings are suppressed.
pred = Xtest*Bdp;
RMSE = sqrt(mean((pred-Ytest).^2));

fprintf('Predictive accuracy (RMSE) of %i SSPOC sensors is %g degrees \n',...
    q, RMSE)
