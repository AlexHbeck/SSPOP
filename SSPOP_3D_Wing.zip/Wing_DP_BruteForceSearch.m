clear all
format long

% Individual Length Models (238 nodes)
 load XTR_2cm.mat  % Matrix for regression
 load XTE_2cm.mat  % Matrix for testing
 XTR = XTR_2cm;
 XTE = XTE_2cm;

% load XTR_1cm.mat
% load XTE_1cm.mat
% XTR = XTR_1cm;
% XTE = XTE_1cm;

% load XTR_5mm.mat
% load XTE_5mm.mat
% XTR = XTR_5mm;
% XTE = XTE_5mm;

% Variable Length (714 nodes)
% load XTR_huge.mat
% load XTE_huge.mat
% XTR = XTR_huge;
% XTE = XTE_huge;

load YTR.mat
load YTE.mat

warning('off','all');
warning;

Number_of_Nodes_N = length(XTR) % number of node locations
Number_of_Sensors_Q = 2 % number of sensors
dp = combinator(Number_of_Nodes_N,Number_of_Sensors_Q,'c'); % all combinations without repetition
number_of_DPs = length(dp)

tic

for i = 1:number_of_DPs
    DP = dp(i,:);
    out = zeros(size(XTR));
    out(:,DP) = XTR(:,DP);
    Bdp = regress(YTR,out); % this regression gives a rank deficient warning
                            % But this is ok becuase the columns are mostly zeros
    pred = XTE*Bdp;
    RMSE(i) = sqrt(mean((pred-YTE).^2));
    i = i+1;
end

[max_num, max_idx]=max(RMSE(:)); % find maximum RMSE and corresponding DP(s)
[X,Y]=ind2sub(size(RMSE),find(RMSE==max_num));
WorstDP = dp(Y,:) % report the worst design point
RMSE_max = RMSE(Y)

[min_num, min_idx]=min(RMSE(:)); % find min accuracy and corresponding DP
[Q,Z]=ind2sub(size(RMSE),find(RMSE==min_num));
Best_DP = dp(Z,:) % report the worst design point(s)
RMSE_min = RMSE(Z)

results = [dp RMSE'];

RMSE_sorted = sort(RMSE,'ascend');

toc


