clear all
%% This code evaluates every possible design point (combanitorial problem)
%   The resulting "RMSE_sorted" variable can be used to find the rank 
%   of the SSPOP Design Point against all possible DPs. For the larger 
%   values of s (or Q from the other code), recommend saving the resulting
%   workspace as this code will take a long time to run.

% Full Model (161 nodes)
% load XTR_full.mat % load velocity matrix for Regression
% load XTE_full.mat % load velocity matrix for Testing

% Constrained model (129 nodes)
load XTR_con.mat
load XTE_con.mat

% XTR = XTR_full;
% XTE = XTE_full;
XTR = XTR_con;
XTE = XTE_con;

load YTR.mat % load AoA matrix for regression
load YTE.mat % load AoA matrix for testing

warning('off','all');
warning;

n = 129 % number of node locations
s = 2 % number of sensors
dp = combinator(n,s,'c'); % all combinations without repetition
num_dp = length(dp)

tic

for i = 1:num_dp
    DP = dp(i,:);
    out = zeros(size(XTR));
    out(:,DP) = XTR(:,DP);
    Bdp = regress(YTR,out); % this regression gives a rank deficient warning
              % But this is ok becuase the columns are mostly zeros
    pred = XTE*Bdp;
    RMSE(i) = sqrt(mean((pred-YTE).^2));
    i = i+1;
end

[max_num, max_idx]=max(RMSE(:)); % find maximum RMSE and corresponding DP(s)
[X,Y]=ind2sub(size(RMSE),find(RMSE==max_num));
WorstDP = dp(Y,:) % report the worst design point
RMSE_max = RMSE(Y)

[min_num, min_idx]=min(RMSE(:)); % find min accuracy and corresponding DP
[Q,Z]=ind2sub(size(RMSE),find(RMSE==min_num));
Best_DP = dp(Z,:) % report the worst design point(s)
RMSE_min = RMSE(Z)

results = [dp RMSE'];

RMSE_sorted = sort(RMSE,'ascend');

toc


