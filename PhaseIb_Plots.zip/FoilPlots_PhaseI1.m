clear all; close all; 

load foil4415.mat; % airfoil coordinates
load foil0012.mat; % NACA 0012 airfoil coords
load removed.mat; % eliminated contrained airfoil coords
load kept.mat; % retained coords
load lam.mat; % laminar-only nodes
load turb.mat; % sometimes turbulent nodes
load top.mat; % top of airfoil coords
load bottom.mat; % bottom of airfoil coords

x = foil4415(:,1);
y = foil4415(:,2);
X = foil0012(:,1);
Y = foil0012(:,2);

DP = [  76	81	84	115	64	74	76	84	36   88   120   127 % Const T=ave
        79	82	85	200	50	75	84	85  1   77   191    200 % Turb = Ave
        79	82	85	118	79	80	86	121	77   83   86   117 	% Laminar
        104	155	156	170	67	88	124	148	125  162  174  182 	% Const T=0
		26	103	154	156	101	109	170	181	79    85  108  121  % Turb = 0
		54	64	80	116	35	49	72	75	40  51  83  194     % Reference
        54 64 80 116 28 57 77 191 24 45 112 170             % Alt Node Con.
        124	164	170	178	136	144	166	181	125  162  174  182 	% Bottom Surf
        20	36	56	64	28	41	55	60	 20   36 64  72     % Top Surf
        15 63 98 146 54 64 97 101 22 70 95 143              % Naca 0012
       ]

DPc=DP;
s = 3; % size of node dots
S = 12; % size of sensor dots
L = 4; %LINE WIDTH

l = 0.1; % title left spacing
r = 0.3; % title vertical spacing

%tit = ["Reference Model" "Turbulence set to Zero" "Turbulence = 1.1 top, 0.9 bottom"]
t1 = tiledlayout(5,2, 'TileSpacing','compact','Padding','compact')
% tiledlayout('flow')


nexttile % Constrained T=Ave
plot(x,y,'b','linewidth',L)
hold on
% plot(removed(:,1),removed(:,2),'x','MarkerFaceColor','r','MarkerSize',s)
plot(kept(:,1),kept(:,2),'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s)
plot(x(DPc(1,1:4)),y(DPc(1,1:4)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16)
plot(x(DPc(1,5:8)),y(DPc(1,5:8)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
plot(x(DPc(1,9:12)),y(DPc(1,9:12)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8) % SSPOP plus search
title("A. Constrained Model: T = 0.9 bottom, 1.1 top", 'Units',  'normalized','HorizontAlalignment', 'left', 'Position', [l,r]);

nexttile % Turb = Ave
plot(x,y,'b','linewidth',L)
hold on
plot(x,y,'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s) 
plot(x(DP(2,1:4)),y(DP(2,1:4)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % Best Possible
plot(x(DP(2,5:8)),y(DP(2,5:8)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
plot(x(DP(2,9:12)),y(DP(2,9:12)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8)% SSPOP plus search
title("B. Full Model: T = 0.9 bottom, 1.1 top", 'Units', 'normalized', 'HorizontAlalignment', 'left', 'Position', [l,r]);

nexttile % Laminar Region Only
plot(x,y,'b','linewidth',L)
hold on
% plot(turb(:,1),turb(:,2),'x','MarkerFaceColor','r','MarkerSize',6)
plot(lam(:,1),lam(:,2),'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize', s)
plot(x(DPc(3,1:4)),y(DPc(3,1:4)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % Best Possible
plot(x(DPc(3,5:8)),y(DPc(3,5:8)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
plot(x(DPc(3,9:12)),y(DPc(3,9:12)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8) % SSPOP plus search
title("C. Laminar Region Only", 'Units', 'normalized','HorizontAlalignment', 'left',  'Position', [l,r]);

nexttile % Constrained T=0
plot(x,y,'b','linewidth',L)
hold on
% plot(removed(:,1),removed(:,2),'x','MarkerFaceColor','r','MarkerSize',6)
plot(kept(:,1),kept(:,2),'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s)
plot(x(DPc(4,1:4)),y(DPc(4,1:4)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16)
plot(x(DPc(4,5:8)),y(DPc(4,5:8)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
plot(x(DPc(4,9:12)),y(DPc(4,9:12)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8) % SSPOP plus search
title("D. Constrained Model: T = 0", 'Units', 'normalized','HorizontAlalignment', 'left',  'Position', [l,r]);

nexttile % Turb = Zero
plot(x,y,'b','linewidth',L)
hold on
  plot(x,y,'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s) 
  plot(x(DP(5,1:4)),y(DP(5,1:4)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % Best Possible
  plot(x(DP(5,5:8)),y(DP(5,5:8)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
plot(x(DP(5,9:12)),y(DP(5,9:12)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8)% SSPOP plus search
title("E. Full Model: T = 0", 'Units', 'normalized', 'HorizontAlalignment', 'left', 'Position', [l,r]);

nexttile % Full Model
plot(x,y,'b','linewidth',L)
hold on
plot(x,y,'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s) 
plot(x(DP(6,1:4)),y(DP(6,1:4)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % Best Possible
plot(x(DP(6,5:8)),y(DP(6,5:8)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
plot(x(DP(6,9:12)),y(DP(6,9:12)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8)% SSPOP plus search
title("F. Full Model", 'Units', 'normalized','HorizontAlalignment', 'left',  'Position', [l,r]);

nexttile % Full Model: Alternate Node Config.
plot(x,y,'b','linewidth',L)
hold on
plot(x,y,'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s) 
plot(x(DP(7,1:4)),y(DP(7,1:4)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16) % Best Possible
plot(x(DP(7,5:8)),y(DP(7,5:8)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
plot(x(DP(7,9:12)),y(DP(7,9:12)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8)% SSPOP plus search
title("G. Full: Alternate Node Configuration", 'Units', 'normalized','HorizontAlalignment', 'left',  'Position', [l,r]);

nexttile % Bottom Surface in Positive AoA
plot(x,y,'b','linewidth',L)
hold on
% plot(removed(:,1),removed(:,2),'x','MarkerFaceColor','r','MarkerSize',6)
plot(bottom(:,1),bottom(:,2),'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s)
plot(x(DPc(8,1:4)),y(DPc(8,1:4)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16)
plot(x(DPc(8,5:8)),y(DPc(8,5:8)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12) % SSPOP
plot(x(DPc(8,9:12)),y(DPc(8,9:12)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8) % SSPOP plus search
title("H. Bottom Surface in Positive AoA", 'Units', 'normalized', 'HorizontAlalignment', 'left', 'Position', [l,r]);

nexttile % Top Surface in Negative AoA
plot(x,y,'b','linewidth',L)
hold on
% plot(removed(:,1),removed(:,2),'x','MarkerFaceColor','r','MarkerSize',6)
plot(top(:,1),top(:,2),'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s)
plot(x(DPc(9,1:4)),y(DPc(9,1:4)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16)   % Best Possible
plot(x(DPc(9,5:8)),y(DPc(9,5:8)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12)   % SSPOP
plot(x(DPc(9,9:12)),y(DPc(9,9:12)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8)  % SSPOP plus search
title("I. Top Surface in Negative AoA", 'Units', 'normalized','HorizontAlalignment', 'left', 'Position', [l,r]);

nexttile % Symmetric 0012 Full Wrap
plot(X,Y,'b','linewidth',L)
hold on
% plot(removed(:,1),removed(:,2),'x','MarkerFaceColor','r','MarkerSize',6)
plot(foil0012(:,1),foil0012(:,2),'o','markeredgecolor','k','MarkerFaceColor','w','MarkerSize',s)
plot(X(DPc(10,1:4)),Y(DPc(10,1:4)),'o','markeredgecolor','k', 'MarkerFaceColor', 'g', 'MarkerSize', 16)   % Best Possible
plot(X(DPc(10,5:8)),Y(DPc(10,5:8)),'o','markeredgecolor','k', 'MarkerFaceColor', 'r', 'MarkerSize', 12)   % SSPOP
plot(X(DPc(10,9:12)),Y(DPc(10,9:12)),'o','markeredgecolor','k', 'MarkerFaceColor', 'y', 'MarkerSize', 8)  % SSPOP plus search
title("J. NACA 0012 Full Wrap", 'Units', 'normalized', 'HorizontAlalignment', 'left','Position', [l,r]);

leg = legend('Airfoil Shape', 'Nodes', 'Best Possible DP', 'SSPOP DP', 'SSPOP + Search DP')
leg.Layout.Tile = 'north';
%title(t1, '4-Sensor DPs')